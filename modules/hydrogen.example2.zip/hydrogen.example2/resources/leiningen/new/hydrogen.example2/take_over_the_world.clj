(ns {{namespace}}.take-over-the-world)

(defn with-diabetes []
  'cookies!)
