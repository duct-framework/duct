(ns hydrogen.example2.duct-profile-test
  (:require [clojure.test :refer :all]
            [hydrogen.example2.duct-profile :refer :all]))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
